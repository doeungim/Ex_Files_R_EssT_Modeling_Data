We Analyse A/B Test data collected from two websites tagged variant A and Variant B

ABTest_Analysis.R - Contains details of the A/B Test Analysis

wrangle-data.R - Creates a datasets and saves as R object in rda directory

ABTest_Analysis.R - generates a normal distribution plot and saves it to the figs directory

ABTest.RMD      - This contains the analysis as an HTML document

ABTestModel.R   -This is a function that can be used for other ABtest results
